using System;

namespace Microsoft.Xna.Framework.Content
{
	public class ContentManager : IDisposable
	{
		public string RootDirectory { get; set; }
		
		
		public ContentManager ()
		{
		}
		
		public void Dispose()
		{
		}
		
		
		public virtual T Load<T> (string assetName)
		{
			string path = RootDirectory + "/" + assetName;
			return default(T);
		}
	}

}

