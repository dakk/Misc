using System;

namespace Microsoft.Xna.Framework
{
	public interface IGraphicsDeviceManager
	{
	}
}

