using System;
using Microsoft.Xna.Framework.Graphics.PackedVector;

namespace Microsoft.Xna.Framework.Graphics
{
	public struct Color : IPackedVector<uint>, IPackedVector, IEquatable<Color>
	{
		public static Color Black;
		public static Color White;
		
		public byte R { get; set; }
		public byte G { get; set; }
		public byte B { get; set; }
		public byte A { get; set; }
		
		public bool Equals(Color c)
		{
			if((c.A == A) && (c.G == G) && (c.B == B) && (c.R == R))
				return true;
			return false;
		}
	}
}

