using System;
using System.Collections.Generic;

namespace Microsoft.Xna.Framework
{
	public class LaunchParameters : Dictionary<string, string>
	{
		public LaunchParameters ()
		{
		}
	}
}

