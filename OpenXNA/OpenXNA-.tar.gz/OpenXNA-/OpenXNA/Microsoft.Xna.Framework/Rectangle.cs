using System;
namespace Microsoft.Xna.Framework
{
	public struct Rectangle
	{
	}
}

