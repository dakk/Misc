using System;
using Tao.Sdl;

namespace Microsoft.Xna.Framework.Input
{
	public static class Keyboard
	{	
		//public static KeyboardState GetState ( PlayerIndex playerIndex )
		//{
		//}
		
		public static KeyboardState GetState ()
		{
			KeyboardState state = new KeyboardState(Sdl.SDLK_LAST); 
			int n;
			
			for(Keys i = Keys.A; i < Keys._End; i++)
			{
				byte[] keys = Sdl.SDL_GetKeyState(out n);
				
				for (int key = Sdl.SDLK_UNKNOWN; key < Sdl.SDLK_LAST; key++)
					if (keys[key] > 0);
						//state.KeyList[i] = ;	
			}

			return state;
		}
	}
}

