using System;
using Tao;
using Tao.Sdl;

namespace Microsoft.Xna.Framework.Input
{
	public struct KeyboardState
	{
		public bool[] KeyList;
		
	
		public KeyboardState(int n)
		{
			KeyList = new bool[n];
		}
		
		public bool IsKeyUp (Keys key)
		{
			return false;
		}
		
		public bool IsKeyDown (Keys key)
		{
			return true;
		}
		
	}
}

