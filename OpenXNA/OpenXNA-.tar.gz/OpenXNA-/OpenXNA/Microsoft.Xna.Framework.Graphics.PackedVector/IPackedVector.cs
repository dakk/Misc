using System;

namespace Microsoft.Xna.Framework.Graphics.PackedVector
{
	public interface IPackedVector
	{
	}
	
	public interface IPackedVector<TPacked> : IPackedVector
	{
	}
}


