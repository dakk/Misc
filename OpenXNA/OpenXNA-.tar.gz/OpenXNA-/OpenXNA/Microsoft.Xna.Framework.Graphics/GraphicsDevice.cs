using Tao.Sdl;
using Microsoft.Xna.Framework.Graphics;
using System;

namespace Microsoft.Xna.Framework
{
	/* Performs primitive-based rendering, creates resources, handles system-level 
	 * variables, adjusts gamma ramp levels, and creates shaders */
	public class GraphicsDevice : IDisposable
	{
		private IntPtr Screen;
		
		public GraphicsDevice (	GraphicsAdapter adapter,
         						GraphicsProfile graphicsProfile,
         						PresentationParameters presentationParameters)
		{
			Screen = Sdl.SDL_SetVideoMode(800, 600, 32, Sdl.SDL_ANYFORMAT);
		}
		
		public void Dispose ()
		{
			
		}
		
		public void Clear(Color c)
		{
		}
	}
}

