using System;

namespace Microsoft.Xna.Framework.Graphics
{
	public sealed class GraphicsAdapter
	{
		public GraphicsAdapter ()
		{
		}
	}
}

