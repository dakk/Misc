using System;
namespace Microsoft.Xna.Framework.Graphics
{
	public interface IGraphicsDeviceService
	{
	}
}

