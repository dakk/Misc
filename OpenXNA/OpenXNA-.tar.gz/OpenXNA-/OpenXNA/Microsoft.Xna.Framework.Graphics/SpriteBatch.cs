using System;

namespace Microsoft.Xna.Framework.Graphics
{
	public class SpriteBatch : GraphicsResource
	{
		public SpriteBatch ()
		{
		}

		public SpriteBatch (GraphicsDevice graphicsDevice)
		{
		}
		
		/* Flushes the sprite batch and restores the device state to how it 
		 * was before Begin was called */
		public void End ()
		{
		}
		
		
		public void Draw ( Texture2D texture, 
		                   Rectangle destinationRectangle,
		                   Color color )
		{
		}

		public void Draw ( Texture2D texture, 
		                   Vector2 position,
		                   Color color )
		{
		}
		
		public void Begin ()
		{
		}
		
	}
}

