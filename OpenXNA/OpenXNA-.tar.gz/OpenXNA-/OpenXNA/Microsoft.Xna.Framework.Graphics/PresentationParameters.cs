using System;

namespace Microsoft.Xna.Framework.Graphics
{
	public class PresentationParameters
	{
		public PresentationParameters ()
		{
		}
	}
}

