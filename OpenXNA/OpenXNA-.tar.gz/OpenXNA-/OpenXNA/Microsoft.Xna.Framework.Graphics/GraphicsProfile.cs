using System;

namespace Microsoft.Xna.Framework.Graphics
{
	public enum GraphicsProfile
	{
		HiDef, 		/* High definition */
		Reach		/* Low definition */
	}
}

