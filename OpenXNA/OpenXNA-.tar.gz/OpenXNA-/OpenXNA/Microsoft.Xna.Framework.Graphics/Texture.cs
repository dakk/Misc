using System;

namespace Microsoft.Xna.Framework.Graphics
{
	public class Texture : GraphicsResource
	{
		public Texture ()
		{
		}
	}
}

