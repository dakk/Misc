using System;

namespace Microsoft.Xna.Framework.Graphics
{
	public class Texture2D : Texture
	{
		public Texture2D ()
		{
		}
	}
}

